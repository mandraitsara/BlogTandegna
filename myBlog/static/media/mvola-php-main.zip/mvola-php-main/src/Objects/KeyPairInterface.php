<?php

namespace MVolaphp\Objects;

interface KeyPairInterface
{
	public function getKey();
	public function getValue();
}