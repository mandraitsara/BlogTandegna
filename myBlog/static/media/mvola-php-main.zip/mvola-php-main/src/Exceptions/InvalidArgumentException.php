<?php
namespace MVolaphp\Exceptions;

use MVolaphp\Exception;

class InvalidArgumentException extends Exception {}