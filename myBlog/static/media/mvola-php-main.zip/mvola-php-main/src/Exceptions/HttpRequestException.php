<?php
namespace MVolaphp\Exceptions;

use MVolaphp\Exception;

class HttpRequestException extends Exception {}