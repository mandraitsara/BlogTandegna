1.1.3 / 2022-06-20
========================

  * Fixed class `DateTime` colision

1.1.2 / 2022-05-13
========================

  * add data errors for unfiled request
  * only partnerName is required for metadata payin

1.1.1 / 2022-05-12
========================

  * add ramsey/uuid package to get uuid

1.1.0 / 2022-05-11
========================

  * add composer for uuid
  * create native uuid for php

1.1.0 / 2022-05-08
========================

  * Add this CHANGES LOG file for update
  * Exception has data to get more specific errors
  * (fixed) Add features list README.md
  * Tests token to handle wrong token
  * (fixed) requestDate to format yyyy-MM-ddTHH:II:ss.SSSZ
  * Datetime class for best format

1.0.1 / 2022-04-07
========================

  * Change namespace to MVolaphp instead of MobileMoney
  * AGPL-v3 to MIT licence
  * Documentation added
  * Cache 

1.0.0-BETA1 / 2022-05-05
========================

  * Initial release